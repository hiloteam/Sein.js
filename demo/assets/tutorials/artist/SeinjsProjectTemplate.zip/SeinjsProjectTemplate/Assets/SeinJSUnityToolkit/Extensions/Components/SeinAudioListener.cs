﻿using UnityEngine;
using System.Collections;

[AddComponentMenu("Sein/Audio Extension/Sein Audio Listener")]
public class SeinAudioListener : MonoBehaviour
{
    // If this listener could sync rotation from node
    public bool rotatable = false;
}
